test_that("digits vignette", {
  test_galley("digits")
})
