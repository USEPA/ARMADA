# jquery_core(3) can be rendered

    Code
      as.character(script)
    Output
      [1] "<script src=\"lib/3.6.0/jquery-3.6.0.min.js\"></script>"

# jquery_core(2) can be rendered

    Code
      as.character(script)
    Output
      [1] "<script src=\"lib/2.2.4/jquery-2.2.4.js\"></script>"

# jquery_core(1) can be rendered

    Code
      as.character(script)
    Output
      [1] "<script src=\"lib/1.12.4/jquery-1.12.4.min.js\"></script>"

