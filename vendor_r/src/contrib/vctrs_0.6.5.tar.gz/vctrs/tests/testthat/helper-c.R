class_type <- function(x) {
  .Call(ffi_class_type, x)
}
