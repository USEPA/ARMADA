library(testthat)
library(shinybusy)

test_check("shinybusy")
