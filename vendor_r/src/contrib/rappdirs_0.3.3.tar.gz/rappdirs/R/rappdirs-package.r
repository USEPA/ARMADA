#' @section Main functions:
#'  * [user_data_dir()]
#'  * [user_config_dir()]
#'  * [user_cache_dir()]
#'  * [site_data_dir()]
#'  * [user_log_dir()]
#' @keywords internal
"_PACKAGE"
