# cross join checks for duplicate names

    Code
      cross_join(df1, df2)
    Condition
      Error in `cross_join()`:
      ! Input columns in `x` must be unique.
      x Problem with `a`.

