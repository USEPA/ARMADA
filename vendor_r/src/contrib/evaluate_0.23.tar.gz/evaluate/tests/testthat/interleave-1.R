for (i in 1:2) {
  cat(i)
  plot(i)
}
