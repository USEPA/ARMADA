library(testthat)
library(gfonts)

test_check("gfonts")
