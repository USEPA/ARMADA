This directory contains files from Tessil's [hopscotch-map library](https://github.com/Tessil/hopscotch-map).

To update to a new version, edit /tools/update_hopscotch_map.R and change `version` to the new version number, then run the script.
