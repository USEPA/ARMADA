library(testthat)
library(fastmap)

test_check("fastmap")
