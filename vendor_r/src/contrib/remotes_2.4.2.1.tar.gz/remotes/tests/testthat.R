library(testthat)
library(remotes)

test_check("remotes")
