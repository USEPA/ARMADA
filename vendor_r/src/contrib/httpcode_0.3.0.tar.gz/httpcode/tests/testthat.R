library(testthat)
library(httpcode)

test_check("httpcode")
