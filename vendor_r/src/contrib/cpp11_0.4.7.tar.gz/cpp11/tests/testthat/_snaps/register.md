# cpp_register: can be run with messages

    Code
      cpp_register(p, quiet = FALSE)
    Message
      i 1 functions decorated with [[cpp11::register]]
      v generated file 'cpp11.R'
      v generated file 'cpp11.cpp'

