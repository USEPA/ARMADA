named <- function(x) set_names(x, chr())

# Until we can reexport from rlang
vars <- function(...) rlang::quos(...)
