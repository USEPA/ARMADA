# at_depth is defunct

    Code
      at_depth()
    Condition
      Error:
      ! `at_depth()` was deprecated in purrr 0.3.0 and is now defunct.
      i Please use `map_depth()` instead.

