# deflate

    Code
      rawToChar(data$output)
    Output
      [1] "Hello world!"

