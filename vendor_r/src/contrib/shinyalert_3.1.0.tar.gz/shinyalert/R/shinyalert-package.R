#' @keywords internal
#' @aliases shinyalert-package
"_PACKAGE"
