This example demonstrates Shiny's versatile `sliderInput` widget. 

Slider inputs can be used to select single values, to select a continuous range of values, and even to animate over a range.
