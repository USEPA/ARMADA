# obj_type_friendly() handles NULL

    Code
      (expect_error(friendly_types(NULL)))
    Output
      <error/rlang_error>
      Error in `vec_type_friendly()`:
      ! `x` must be a vector.

