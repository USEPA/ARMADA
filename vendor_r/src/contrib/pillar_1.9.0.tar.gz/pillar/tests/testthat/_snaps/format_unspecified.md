# smoke test

    Code
      pillar(unspecified(3), width = 10)
    Output
      <pillar>
      <???>
          .
          .
          .

